package com.stackroute.activitystream.usercircleservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserCircleServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserCircleServiceApplication.class, args);
	}
}
