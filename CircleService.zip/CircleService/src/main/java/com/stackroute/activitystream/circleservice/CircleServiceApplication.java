package com.stackroute.activitystream.circleservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CircleServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CircleServiceApplication.class, args);
	}
}
